/**
 * 
 */
/**
 * 
 */
module VariablesyOperaciones0 {
}